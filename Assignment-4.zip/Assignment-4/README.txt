This is the Assignment - 4 submission for Madhav Datt (14CS30015) and Avikalp Srivastava (14CS10008).
It includes the following:
	- SRS Document
	- SA / SD Document
	- All UML Diagrams in image and XML format (can be imported into Visual Paradigm)
